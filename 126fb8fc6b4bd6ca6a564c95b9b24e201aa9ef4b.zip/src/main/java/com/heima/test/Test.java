package com.heima.test;

public class Test {
    public static void main(String[] args) {
        System.out.println("你好,未来!");
    }

}
